![Thumbnail video tutorial](https://github.com/wass08/r3f-portfolio-avatar/assets/6551176/b4a8f0ba-a94d-410f-b222-f2c8a983d562)


[Video tutorial](https://youtu.be/pGMKIyALcK0)


### Build your own avatar
[Ready Player Me](https://readyplayer.me/)
